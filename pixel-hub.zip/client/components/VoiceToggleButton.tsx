import { Button } from "@/components/ui/button";
import { Mic, Square } from "lucide-react";
import { cn } from "@/lib/utils";
import BeatBlob from "./BeatBlob";

export default function VoiceToggleButton({ active, speaking, onToggle, level = 0 }: { active: boolean; speaking?: boolean; onToggle: () => void; level?: number }) {
  const scale = 1 + level * 0.12;
  return (
    <div className="relative flex flex-col items-center gap-4">
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center" aria-hidden>
        {active && (
          <div style={{ transform: `scale(${1 + level * 0.25})`, transition: "transform 80ms ease" }}>
            <BeatBlob size={210} level={level} />
          </div>
        )}
      </div>
      <Button
        aria-pressed={active}
        onClick={onToggle}
        className={cn(
          "group relative h-28 w-28 rounded-full text-base font-semibold transition-all md:h-40 md:w-40",
          active
            ? "bg-gradient-to-br from-brand-start to-brand-end text-white shadow-xl ring-4 ring-primary/20 hover:brightness-110"
            : "bg-secondary text-foreground hover:bg-secondary/90"
        )}
        style={{ transform: `scale(${scale})`, transition: "transform 80ms ease" }}
      >
        <span
          className={cn(
            "absolute -inset-3 rounded-full blur-2xl transition-opacity",
            active ? "bg-gradient-to-br from-brand-start/40 to-brand-end/40 opacity-60" : "opacity-0"
          )}
        />
        <span className="relative z-10" style={{ transform: `scale(${1 + level * 0.15})`, transition: "transform 80ms ease" }}>
          {active ? <Square className="h-10 w-10" /> : <Mic className="h-10 w-10" />}
        </span>
      </Button>
      <div className="text-sm text-muted-foreground">
        {active ? (speaking ? "Speaking…" : "Listening…") : "Start Conversation"}
      </div>
    </div>
  );
}
