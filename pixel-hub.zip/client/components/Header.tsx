import { Button } from "@/components/ui/button";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";

export default function Header() {
  const { theme, setTheme } = useTheme();
  const isDark = theme === "dark";
  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container h-16 flex items-center justify-between">
        <div className="flex items-baseline gap-3">
          <h1 className="text-xl md:text-2xl font-extrabold tracking-tight bg-gradient-to-r from-brand-start to-brand-end bg-clip-text text-transparent">
            Voice AI Agent
          </h1>
          <span className="hidden md:inline text-sm text-muted-foreground">
            Web-based Voice AI Conversational Agent
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Button
            aria-label="Toggle dark mode"
            variant="outline"
            size="icon"
            className="rounded-full"
            onClick={() => setTheme(isDark ? "light" : "dark")}
          >
            <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
            <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            <span className="sr-only">Toggle theme</span>
          </Button>
        </div>
      </div>
    </header>
  );
}
