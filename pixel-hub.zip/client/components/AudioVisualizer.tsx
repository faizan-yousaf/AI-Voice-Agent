import { useMemo } from "react";

export default function AudioVisualizer({ speaking = false, level }: { speaking?: boolean; level?: number }) {
  const seeds = useMemo(() => Array.from({ length: 24 }, () => 0.5 + Math.random() * 0.9), []);
  const bars = seeds.length;
  return (
    <div className="flex h-12 items-end justify-center gap-1" aria-hidden={!speaking}>
      {Array.from({ length: bars }).map((_, i) => {
        const mult = seeds[i];
        const h = 6 + (level ?? 0) * 42 * mult;
        return (
          <span
            key={i}
            className={`w-1.5 origin-bottom rounded-full bg-gradient-to-b from-brand-start to-brand-end ${speaking ? "" : "opacity-40"}`}
            style={{ height: `${h}px`, transition: "height 80ms ease" }}
          />
        );
      })}
    </div>
  );
}
