import { cn } from "@/lib/utils";

function Indicator({ label, ok }: { label: string; ok: boolean }) {
  return (
    <div className={cn("inline-flex items-center gap-2 rounded-full border px-3 py-1 text-xs shadow-sm", ok ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300" : "bg-muted text-muted-foreground")}
      aria-label={`${label}: ${ok ? "on" : "off"}`}
    >
      <span className={cn("h-2 w-2 rounded-full", ok ? "bg-emerald-500" : "bg-gray-400 dark:bg-gray-600")}></span>
      <span>{label}</span>
    </div>
  );
}

export default function StatusBar({ connected, active }: { connected: boolean; active: boolean }) {
  return (
    <footer className="fixed bottom-0 inset-x-0 z-40">
      <div className="container py-2">
        <div className="mx-auto flex w-full max-w-xl items-center justify-center gap-2 rounded-full border bg-card/80 px-3 py-2 shadow-lg backdrop-blur supports-[backdrop-filter]:bg-card/60">
          <Indicator label="Connected to LiveKit" ok={connected} />
          <Indicator label={active ? "Session Active" : "Session Idle"} ok={active} />
        </div>
      </div>
    </footer>
  );
}
