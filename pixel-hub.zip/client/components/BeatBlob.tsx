import { useMemo } from "react";

export default function BeatBlob({ size = 160, level = 0 }: { size?: number; level?: number }) {
  // Stable random seeds for lobes
  const seeds = useMemo(() => Array.from({ length: 24 }, () => Math.random()), []);
  const r = size / 2;
  const points = seeds.map((s, i) => {
    const angle = (i / seeds.length) * Math.PI * 2;
    const amp = 0.35 + s * 0.65; // 0.35..1
    const radius = r * (0.82 + amp * 0.25 * level); // vary with level
    const x = r + radius * Math.cos(angle);
    const y = r + radius * Math.sin(angle);
    return `${i === 0 ? "M" : "L"}${x.toFixed(2)} ${y.toFixed(2)}`;
  });
  const d = `${points.join(" ")} Z`;

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} aria-hidden>
      <defs>
        <linearGradient id="beatGrad" x1="0" x2="1" y1="0" y2="1">
          <stop offset="0%" stopColor={`hsl(var(--brand-start))`} />
          <stop offset="100%" stopColor={`hsl(var(--brand-end))`} />
        </linearGradient>
      </defs>
      <path d={d} fill="url(#beatGrad)" opacity={0.18 + level * 0.22} />
    </svg>
  );
}
