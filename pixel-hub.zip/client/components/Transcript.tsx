import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";

export type TranscriptMessage = {
  id: string;
  role: "user" | "ai";
  text: string;
};

export default function Transcript({ messages }: { messages: TranscriptMessage[] }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [messages]);

  return (
    <div
      ref={ref}
      className="h-[46vh] md:h-[62vh] overflow-y-auto rounded-xl border bg-card p-4 shadow-sm"
      aria-live="polite"
      aria-relevant="additions"
    >
      <div className="space-y-3">
        {messages.map((m) => (
          <div key={m.id} className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}>
            <div
              className={cn(
                "max-w-[85%] rounded-2xl px-4 py-3 text-sm shadow-sm",
                m.role === "user"
                  ? "bg-gradient-to-br from-brand-start to-brand-end text-white"
                  : "bg-muted text-foreground"
              )}
            >
              <div className={cn("mb-1 text-[10px] uppercase tracking-wide", m.role === "user" ? "text-white/80" : "text-muted-foreground")}>{m.role === "user" ? "User" : "AI"}</div>
              <div className="leading-relaxed">{m.text}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
