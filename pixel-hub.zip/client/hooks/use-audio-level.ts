import { useEffect, useRef, useState } from "react";

function clamp(v: number, min = 0, max = 1) {
  return Math.min(max, Math.max(min, v));
}

export function useAudioLevel(enabled: boolean) {
  const [level, setLevel] = useState(0);
  const raf = useRef<number | null>(null);
  const tRef = useRef(0);
  const targetRef = useRef(0);

  useEffect(() => {
    const loop = () => {
      tRef.current += 0.016;
      if (enabled) {
        // Compose a few waves and random spikes to simulate a beat
        const base = (Math.sin(tRef.current * 2.2) + 1) / 2; // 0..1
        const wave = (Math.sin(tRef.current * 5.1) + 1) / 2;
        const noise = Math.random() * 0.15;
        let next = 0.25 * base + 0.6 * wave + noise;
        // Occasionally emphasize a beat
        if (Math.random() < 0.08) next += 0.6;
        targetRef.current = clamp(next);
      } else {
        targetRef.current = 0;
      }
      // Smooth using exponential moving average
      const current = level;
      const smoothed = current + (targetRef.current - current) * 0.18;
      const value = clamp(smoothed);
      setLevel(value);
      raf.current = requestAnimationFrame(loop);
    };
    raf.current = requestAnimationFrame(loop);
    return () => {
      if (raf.current) cancelAnimationFrame(raf.current);
      raf.current = null;
    };
  }, [enabled]);

  return level;
}
