import { useEffect, useMemo, useRef, useState } from "react";
import VoiceToggleButton from "@/components/VoiceToggleButton";
import Transcript, { type TranscriptMessage } from "@/components/Transcript";
import AudioVisualizer from "@/components/AudioVisualizer";
import StatusBar from "@/components/StatusBar";
import { useAudioLevel } from "@/hooks/use-audio-level";

export default function Index() {
  const [active, setActive] = useState(false);
  const [connected] = useState(true);
  const [aiSpeaking, setAiSpeaking] = useState(false);
  const level = useAudioLevel(aiSpeaking);
  const [messages, setMessages] = useState<TranscriptMessage[]>([
    { id: "m0", role: "ai", text: "Hi! I'm your Voice AI agent. Tap the button to start talking." },
  ]);

  const timeouts = useRef<number[]>([]);

  useEffect(() => {
    return () => {
      timeouts.current.forEach((t) => clearTimeout(t));
      timeouts.current = [];
    };
  }, []);

  useEffect(() => {
    // Clear any scheduled tasks when toggling
    timeouts.current.forEach((t) => clearTimeout(t));
    timeouts.current = [];

    if (!active) {
      setAiSpeaking(false);
      return;
    }

    const schedule = () => {
      const uid = crypto.randomUUID();
      const tid = window.setTimeout(() => {
        setMessages((prev) => [
          ...prev,
          { id: uid, role: "user", text: "What's the weather like today?" },
        ]);
      }, 400);
      timeouts.current.push(tid);

      const speakOn = window.setTimeout(() => setAiSpeaking(true), 1100);
      timeouts.current.push(speakOn);

      const aid = crypto.randomUUID();
      const reply = window.setTimeout(() => {
        setMessages((prev) => [
          ...prev,
          { id: aid, role: "ai", text: "Currently sunny with a light breeze. Highs around 24°C." },
        ]);
        setAiSpeaking(false);
      }, 2400);
      timeouts.current.push(reply);

      // Queue another cycle
      const next = window.setTimeout(() => {
        if (active) schedule();
      }, 4200);
      timeouts.current.push(next);
    };

    schedule();
  }, [active]);

  const layout = useMemo(
    () => (
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:gap-10">
        <div className="flex flex-col items-center justify-start gap-6">
          <div className="mt-2" />
          <VoiceToggleButton active={active} speaking={aiSpeaking} onToggle={() => setActive((v) => !v)} level={level} />
          <AudioVisualizer speaking={aiSpeaking} level={level} />
          <p className="max-w-md text-center text-sm text-muted-foreground">
            Tap once to start. The agent listens and responds continuously. The button morphs with the voice beat.
          </p>
        </div>
        <div>
          <h2 className="mb-3 text-lg font-semibold tracking-tight">Live Transcript</h2>
          <Transcript messages={messages} />
        </div>
      </div>
    ),
    [active, aiSpeaking, messages, level],
  );

  return (
    <>
      {layout}
      <StatusBar connected={connected} active={active} />
    </>
  );
}
